package com.example.BookCrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
